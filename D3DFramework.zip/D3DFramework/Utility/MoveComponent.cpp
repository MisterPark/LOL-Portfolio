#include "stdafx.h"
#include "MoveComponent.h"

MoveComponent::MoveComponent()
{
}

MoveComponent::~MoveComponent()
{
}

void MoveComponent::Initialize()
{

}

void MoveComponent::Release()
{
}

void MoveComponent::Update()
{
}

