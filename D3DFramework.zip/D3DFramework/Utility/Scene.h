#pragma once

class Layer;

class Scene
{


public:

	map<wstring, Layer*> layerMap;
};

