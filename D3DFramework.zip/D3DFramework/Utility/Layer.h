#pragma once

class GameObject;

class Layer
{
public:



	map<std::wstring, GameObject*> objectMap;
};

