#pragma once


// Windows ��� ����
#include <windows.h>
// C ��Ÿ�� ��� �����Դϴ�.
#include <stdlib.h>
#include <malloc.h>
#include <memory.h>
#include <tchar.h>

#include <iostream>
#include <map>
#include <string>
#include  <locale>
#include <corecrt_wstring.h>
using namespace std;
#include "Management.h"
#include "Scene.h"
#include "Layer.h"
#include "GameObject.h"
#include "Component.h"

