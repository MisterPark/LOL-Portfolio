#include "stdafx.h"
#include "Vertex.h"

Vertex::Vertex(float _x, float _y, float _z, D3DCOLOR _color)
{
	this->x = _x;
	this->y = _y;
	this->z = _z;
	this->color = _color;

}
