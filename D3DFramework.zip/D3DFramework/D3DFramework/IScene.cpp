#include "stdafx.h"
#include "IScene.h"
