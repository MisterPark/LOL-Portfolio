#include "stdafx.h"
#include "Building.h"

Building::Building()
{
}

Building::~Building()
{
}
