#include "stdafx.h"
#include "IJob.h"

IJob::IJob()
{
}

IJob::~IJob()
{
}
