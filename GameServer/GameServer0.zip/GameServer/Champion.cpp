#include "stdafx.h"
#include "Champion.h"

Champion::Champion()
{
}

Champion::~Champion()
{
}

void Champion::Initialize()
{
	Unit::Initialize();

}

void Champion::Release()
{
	Unit::Release();
}

void Champion::Update()
{
	Unit::Update();
}
