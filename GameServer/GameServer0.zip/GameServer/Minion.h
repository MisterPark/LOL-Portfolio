#pragma once
#include "Unit.h"
class Minion :
    public Unit
{
public:
    Minion();
    virtual ~Minion();
};

