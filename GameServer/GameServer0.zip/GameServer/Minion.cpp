#include "stdafx.h"
#include "Minion.h"

Minion::Minion()
{
}

Minion::~Minion()
{
}
