#pragma once
#include "Unit.h"
class Bush :
    public Unit
{
public:
    Bush();
    virtual ~Bush();
};

