#pragma once
#include "Building.h"
class Turret :
    public Building
{
public:
    Turret();
    virtual ~Turret();
};

